const searchInput = document.getElementById('searchInput');

const filterBtns = document.querySelectorAll('.filter-btn');

const fatwaCards = document.querySelectorAll('.fatwa-card');

// وظيفة البحث والفلترة معاً

function updateDisplay() {

    const searchTerm = searchInput.value.toLowerCase();

    const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;

    fatwaCards.forEach(card => {

        const text = card.innerText.toLowerCase();

        const marja = card.dataset.marja;

        

        const matchesSearch = text.includes(searchTerm);

        const matchesFilter = (activeFilter === 'all' || marja === activeFilter);

        if (matchesSearch && matchesFilter) {

            card.style.display = "block";

        } else {

            card.style.display = "none";

        }

    });

}

// مستمع لحدث الكتابة في البحث

searchInput.addEventListener('input', updateDisplay);

// مستمع لحدث الضغط على أزرار المراجع

filterBtns.forEach(btn => {

    btn.addEventListener('click', () => {

        filterBtns.forEach(b => b.classList.remove('active'));

        btn.classList.add('active');

        updateDisplay();

    });

});

// رسالة نجاح عند الإرسال

document.getElementById('fatwaForm').onsubmit = (e) => {

    e.preventDefault();

    alert('شكراً لك، تم استلام سؤالك وسيعرض بعد التدقيق الشرعي.');

};

